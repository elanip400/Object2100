package com.example.TobiasOblig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TobiasObligApplicationTests {

	@Test
	void contextLoads() {
	}

}
